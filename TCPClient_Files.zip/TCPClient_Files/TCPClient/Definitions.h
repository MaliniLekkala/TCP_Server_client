#define DEFAULT_BUFLEN 512
#define DEFAULT_PORT "27015"
#define HEART_BEAT_TIMER 20000 //in seconds
#define IPAddress "192.168.0.13"
#define NumberOFDevices 5
#define RequestBufferSize sizeof(Request)
#define ResponseBufferSize sizeof(Response)
enum RequestType
{
	REQ_INITIALIZE,
	REQ_ENABLE,
	REQ_DISABLE,
	REQ_STATUS,
	REQ_HEARTBEAT
};

enum ResponseErrorCodes
{
	RESError_Success,
	RESError_Failed,
	RESError_FailedNoConnection
};

enum DeviceStatus
{
	STATUS_InitEnable,
	STATUS_InitDisable,
	STATUS_UnInitialized
};

struct Request
{
	UINT32 iRequestID;
	UINT32 iDeviceID;
	UINT32 binRequest;
};

struct Response
{
	UINT32 iResponseID;
	UINT32 iDeviceID;
	UINT32 responseStatus;
	UINT32 error;
};
