// TCPClient.cpp 

#include "stdafx.h"
#include "TCPClient.h"
int TCPClient::Connect(PCSTR strIPAddress, PCSTR strPort )
{
	// Initialize Winsock
	iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0) {
		printf("WSAStartup failed with error: %d\n", iResult);
		return 1;
	}

	ZeroMemory(&hints, sizeof(hints));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;

	// Resolve the server address and port
	iResult = getaddrinfo(strIPAddress, strPort, &hints, &result);
	if (iResult != 0) {
		printf("Getaddrinfo failed with error: %d\n", iResult);
		WSACleanup();
		return 1;
	}

	// Attempt to connect to an address until one succeeds
	for (ptr = result; ptr != NULL; ptr = ptr->ai_next) {

		// Create a SOCKET for connecting to server
		ConnectSocket = socket(ptr->ai_family, ptr->ai_socktype,
			ptr->ai_protocol);
		if (ConnectSocket == INVALID_SOCKET) {
			printf("Socket failed with error: %ld\n", WSAGetLastError());
			WSACleanup();
			return 1;
		}

		// Connect to server.
		iResult = connect(ConnectSocket, ptr->ai_addr, (int)ptr->ai_addrlen);
		if (iResult == SOCKET_ERROR) {
			closesocket(ConnectSocket);
			ConnectSocket = INVALID_SOCKET;
			continue;
		}
		break;
	}

	freeaddrinfo(result);

	if (ConnectSocket == INVALID_SOCKET) {
		printf("Unable to connect to server!\n");
		WSACleanup();
		return 1;
	}
	return 0;
}
int TCPClient::SendReceiveMessages()
{
	Request req{ 0, 0, 0 };
	static int iRequestID = 0;
	for (int i = 1; i <= NumberOFDevices; i++)
	{
		Request req = { iRequestID++, i, REQ_INITIALIZE };
		// Send request to initialize device
		iResult = send(ConnectSocket, (char*)&req, (int)sizeof(req), 0);
		if (iResult == SOCKET_ERROR) {
			cout<<"send failed with error: "<< WSAGetLastError()<<endl;
			closesocket(ConnectSocket);
			WSACleanup();
			return 1;
		}
		cout << "Send packet to initialize device Id " << i<<endl;
		Sleep(1000);
		ReceiveMessage();
		Sleep(1000);
		req = { iRequestID++, i, REQ_ENABLE };
		// Send request to enable device
		iResult = send(ConnectSocket, (char*)&req, (int)sizeof(req), 0);
		if (iResult == SOCKET_ERROR) {
			printf("send failed with error: %d\n", WSAGetLastError());
			closesocket(ConnectSocket);
			WSACleanup();
			return 1;
		}
		cout << "Send packet to enable device Id " << i << endl;
		Sleep(1000);
		ReceiveMessage();
		Sleep(1000);
		req = { iRequestID++, i, REQ_DISABLE };
		// Send request to disable device
		iResult = send(ConnectSocket, (char*)&req, (int)sizeof(req), 0);
		if (iResult == SOCKET_ERROR) {
			printf("send failed with error: %d\n", WSAGetLastError());
			closesocket(ConnectSocket);
			WSACleanup();
			return 1;
		}
		cout << "Send packet to disable device Id " << i << endl;

		Sleep(1000);
		ReceiveMessage();
		Sleep(1000);
		req = { iRequestID++, i, REQ_STATUS };
		// Send request for status of device
		iResult = send(ConnectSocket, (char*)&req, (int)sizeof(req), 0);
		if (iResult == SOCKET_ERROR) {
			printf("send failed with error: %d\n", WSAGetLastError());
			closesocket(ConnectSocket);
			WSACleanup();
			return 1;
		}
		cout << "Send packet to get status of device Id " << i << endl;
		Sleep(1000);
		ReceiveMessage();

	}
	Sleep(HEART_BEAT_TIMER / 2);
	req = { 0, 0, REQ_HEARTBEAT };
	// Send an initial buffer
	iResult = send(ConnectSocket, (char*)&req, (int)sizeof(req), 0);
	if (iResult == SOCKET_ERROR) {
		printf("send failed with error: %d\n", WSAGetLastError());
		closesocket(ConnectSocket);
		WSACleanup();
		return 1;
	}
	Sleep(HEART_BEAT_TIMER*2);
	// shutdown the connection since no more data will be sent
	iResult = shutdown(ConnectSocket, SD_SEND);
	if (iResult == SOCKET_ERROR) {
		printf("shutdown failed with error: %d\n", WSAGetLastError());
		closesocket(ConnectSocket);
		WSACleanup();
		return 1;
	}

	// cleanup
	closesocket(ConnectSocket);
	WSACleanup();
	return 0;
}
void TCPClient::ReceiveMessage() 
{
	iResult = recv(ConnectSocket, recvbuf, recvbuflen, 0);
	if (iResult > 0)
	{ 
		Response* resp = (Response*)recvbuf;
		g_oQueue.Push(*resp);
		if (resp->error == RESError_Success)
		{
			switch (resp->responseStatus)
			{
			case STATUS_InitEnable:
				cout << "Succesfully received data from server for device ID " << resp->iDeviceID << " and status is Initialized and Enabled" << endl;
				break;
			case STATUS_InitDisable:
				cout << "Succesfully received data from server for device ID " << resp->iDeviceID << " and status is Initialized and disabled" << endl;
				break;
			case STATUS_UnInitialized:
				cout << "Succesfully received data from server for device ID " << resp->iDeviceID << " and status is Uninitialized " << endl;
				break;
			default:
				break;
			}
		}
	}
	else if (iResult == 0)
		printf("Connection closed\n");
	else
		printf("Recv failed with error: %d\n", WSAGetLastError());
	return;
}
int __cdecl main(int argc, char **argv)
{
	TCPClient clientObj;
	clientObj.Connect(IPAddress, DEFAULT_PORT);
	clientObj.SendReceiveMessages();
	return 0;
}

