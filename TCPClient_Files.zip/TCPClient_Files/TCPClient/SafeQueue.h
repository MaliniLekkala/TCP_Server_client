// QueueImplementation.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#include <iostream>
#include <queue>
#include <string>
#include <process.h>
#include "Definitions.h"
using namespace std;
template<typename T>
class CSafeQueue
{
private:
	queue<T>	m_oQueue;	//contains the actual data
	CRITICAL_SECTION		m_csQueueData;	//to synchroize access to m_csQueueData among multiple threads
	HANDLE					m_hEvent;	//for signalling presence of absence of data
public:
	//create a manual reset event initially signalled.
	//This event will be signalled and shall remain so whenever there is data in the queue and
	//it shall be reset as long as queue is empty
	CSafeQueue()
	{
		InitializeCriticalSection(&m_csQueueData);
		m_hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	};
	//close the event handle
	~CSafeQueue()
	{
		DeleteCriticalSection(&m_csQueueData);
		CloseHandle(m_hEvent);
	};
	T front()
	{
		T data = m_oQueue.front();
		return data;
	}
	//public methods to Push data to queue
	void Push(T& oNewData)
	{
		EnterCriticalSection(&m_csQueueData);
		//push new element to queue
		m_oQueue.push(oNewData);

		//now that there is atleast one element, set the event
		SetEvent(m_hEvent);
		LeaveCriticalSection(&m_csQueueData);
	};
	//public methods to Pop data from queue
	T Pop()
	{
		EnterCriticalSection(&m_csQueueData);
		T popData = NULL;
		if (m_oQueue.size())
		{
			//first get the topmost data block
			popData = m_oQueue.front();
			//next remove it from queue
			m_oQueue.pop();
		}
		//now, check for new size.. if no more elements in queue
		//reset the event
		if (!m_oQueue.size())
			ResetEvent(m_hEvent);

		LeaveCriticalSection(&m_csQueueData);
		return popData;
	};

	//helper method to get the event handle
	HANDLE GetEvent(){ return m_hEvent; };
};