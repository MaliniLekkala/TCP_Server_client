#undef UNICODE

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <queue>
#include "Device.h"
#include "SafeQueue.h"
#include <iostream>
#include <memory>

using namespace std;

// Need to link with Ws2_32.lib
#pragma comment (lib, "Ws2_32.lib")
typedef unique_ptr<Request> ReqPtr;
class TCPServer
{
public:
	TCPServer();
	~TCPServer();

	INT Connect(PCSTR strPort);
	INT ReceiveMessages();
	INT Disconnect();

	static VOID CALLBACK StaticHeartBeatTimeout(void* lpParametar,	BOOLEAN TimerOrWaitFired);

	bool GetClientAlive()
	{
		return IsClientAlive;
	}
	bool SetClientAlive(bool IsAlive)
	{
		return IsClientAlive = IsAlive;
	}

	HANDLE GetDisconnectEvent()
	{
		return hProcessMessagesDisconnectEvent;
	}

	HANDLE GetProcessMessagesComplete()
	{
		return hProcessMessagesCompleteEvent;
	}

	SOCKET GetClientSocket()
	{
		return ClientSocket;
	}

	CSafeQueue<Request*> queue;
	Device* ObjDevices;

private:
	INT CreateEventForClientProcessMessages();
	INT StartHeartBeatTimer();
	INT DeleteHeartBeatTimer();

	UINT TimerId;

	SOCKET ListenSocket;
	SOCKET ClientSocket;

	struct addrinfo *resAddInfo;

	char recvbuf[RequestBufferSize];

	HANDLE hProcessMessagesDisconnectEvent;
	HANDLE hProcessMessagesCompleteEvent;
	HANDLE hProcessMessagesThread;
	DWORD dwThreadID;



	HWND hwnd;
	bool IsClientAlive;

	HANDLE m_timerHandle;
};