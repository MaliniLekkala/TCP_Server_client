#include "stdafx.h"
#include "TCPServer.h"

DWORD WINAPI ProcessMessages(LPVOID lpParam);
//Constructor
TCPServer::TCPServer()
{
	ListenSocket = INVALID_SOCKET;
	ClientSocket = INVALID_SOCKET;
	resAddInfo = NULL;
	SetClientAlive(false);
	TimerId = 0;
	dwThreadID = 0;
	//Emulating dummy devices
	static int Id = 1;
	ObjDevices = new Device[NumberOFDevices];
	for (int i = 0; i < NumberOFDevices; i++)
	{
		ObjDevices[i].SetDeviceID(Id);
		ObjDevices[i].SetDeviceInitialized(false);
		ObjDevices[i].SetDeviceEnabled(false);
		ObjDevices[i].SetDeviceStatus(STATUS_UnInitialized);
		Id++;
	}
	//Create events and thread to process messages.
	CreateEventForClientProcessMessages();
}
//Destructor
TCPServer::~TCPServer()
{
	delete[] ObjDevices;
	//close the thread handle and event handles
	CloseHandle(hProcessMessagesThread);
	CloseHandle(hProcessMessagesDisconnectEvent);
	CloseHandle(hProcessMessagesCompleteEvent);
	TerminateThread(hProcessMessagesThread, 0);
}
//Connection to socket and ready to accept client
INT TCPServer::Connect(PCSTR strPort)
{
	INT iResult = 0;
	struct addrinfo structAddInfo;

	ZeroMemory(&structAddInfo, sizeof(structAddInfo));
	structAddInfo.ai_family = AF_INET;
	structAddInfo.ai_socktype = SOCK_STREAM;
	structAddInfo.ai_protocol = IPPROTO_TCP;
	structAddInfo.ai_flags = AI_PASSIVE;

	// Resolve the server address and port
	iResult = getaddrinfo(NULL, strPort, &structAddInfo, &resAddInfo);
	if (iResult != 0) {
		cout<<"Getaddrinfo failed with error: "<<iResult<<endl;
		return 1;
	}

	// Create a SOCKET for connecting to server
	ListenSocket = socket(resAddInfo->ai_family, resAddInfo->ai_socktype, resAddInfo->ai_protocol);
	if (ListenSocket == INVALID_SOCKET) {
		cout<<"Socket failed with error: "<<WSAGetLastError()<<endl;
		freeaddrinfo(resAddInfo);
		return 1;
	}

	// Setup the TCP listening socket
	iResult = bind(ListenSocket, resAddInfo->ai_addr, (int)resAddInfo->ai_addrlen);
	if (iResult == SOCKET_ERROR) {
		cout<<"Bind failed with error: "<<WSAGetLastError();
		freeaddrinfo(resAddInfo);
		closesocket(ListenSocket);
		return 1;
	}

	freeaddrinfo(resAddInfo);
	
	//Listen to socket
	iResult = listen(ListenSocket, SOMAXCONN);
	if (iResult == SOCKET_ERROR) {
		cout<<"Listen failed with error: "<< WSAGetLastError()<<endl;
		closesocket(ListenSocket);
		return 1;
	}
	cout << "Ready to accept connection from client"<<endl;

	// Accept a client socket
	ClientSocket = accept(ListenSocket, NULL, NULL);
	if (ClientSocket == INVALID_SOCKET) {
		cout<<"Accept failed with error: "<< WSAGetLastError()<<endl;
		closesocket(ListenSocket);
		return 1;
	}
	cout << "Accepted connection from client" << endl;
	// No longer need server socket
	closesocket(ListenSocket);
	IsClientAlive = true;

	//Create heart beat timer to check client status
	if (StartHeartBeatTimer() == 0)
	{
		return 1;
	}
	return 0;
}
//Disconnect from client
int TCPServer::Disconnect()
{
	//Close socket and delete heartbeat
	closesocket(ClientSocket);
	DeleteHeartBeatTimer();
	SetEvent(GetProcessMessagesComplete()); //Empty queue
	//Wait for queue to be emptied before proceeding for next connection
	WaitForSingleObject(GetProcessMessagesComplete(), INFINITE);
	ResetEvent(GetProcessMessagesComplete());
	cout << "Client disconnected" << endl;

	return 0;
}
//Start heart beat timer
INT TCPServer::StartHeartBeatTimer()
{
	INT iResult = ::CreateTimerQueueTimer(
		&m_timerHandle,
		NULL,
		(WAITORTIMERCALLBACK)StaticHeartBeatTimeout,
		this,
		HEART_BEAT_TIMER,
		HEART_BEAT_TIMER,
		WT_EXECUTEINTIMERTHREAD);
	if (iResult == 0)
	{
		cout << "Heart beat timer creation failed" << endl;
	}
	return iResult;
}
//Callback function for heartbeat timeout
VOID CALLBACK TCPServer::StaticHeartBeatTimeout(void* lpParametar,	BOOLEAN TimerOrWaitFired)
{
	TCPServer* objServer = (TCPServer*)lpParametar;
	if (objServer->GetClientAlive() == false)
	{
		cout << "Connection from client timedout" << endl;
		closesocket(objServer->ClientSocket);
	}
	else
	{
		objServer->SetClientAlive(false);
	}
}
//Delete heartbeat timer when done
INT TCPServer::DeleteHeartBeatTimer()
{
	INT iResult = DeleteTimerQueueTimer(NULL, m_timerHandle, NULL);
	return iResult;
}
//Receive messages from client once connection is accepted.
int TCPServer::ReceiveMessages()
{
	INT iResult = 0;
	do {
		cout << "Waiting for receiving" << endl;
		//Receive is a blocking call. Receive until message is received or the peer shuts down the connection or times out. 
		//In timer callback, socket will be closed and receive will fail
		iResult = recv(ClientSocket, recvbuf, RequestBufferSize, 0);
		if (iResult > 0)
		{
			Request* tRcv = (Request *)recvbuf;
			cout << "Pushing into processing queue" << endl;
			queue.Push(tRcv);
			//Considering any messages from client as heart beat and setting the flag
			SetClientAlive(true);
		}
		else 
		{
			cout<<"Recv failed with error:"<< WSAGetLastError()<<endl;
		}
	} while (iResult > 0);

	return iResult;
}
//To create events, thread for processing of messages.
INT TCPServer::CreateEventForClientProcessMessages()
{
	hProcessMessagesDisconnectEvent = CreateEvent(
	NULL,               // default security attributes
	TRUE,               // manual-reset event
	FALSE,              // initial state is nonsignaled
	TEXT("ProcessMessagesDisconnect")  // object name
	);

	if (hProcessMessagesDisconnectEvent == NULL)
	{
		cout<<"CreateEvent for process messages disconnect failed"<< GetLastError()<<endl;
		return 1;
	}

	hProcessMessagesCompleteEvent = CreateEvent(
		NULL,               // default security attributes
		TRUE,               // manual-reset event
		FALSE,              // initial state is nonsignaled
		TEXT("ProcessMessagesComplete")  // object name
		);

	if (hProcessMessagesCompleteEvent == NULL)
	{
		cout << "CreateEvent for process messages complete failed" << GetLastError() << endl;
		return 1;
	}
	// Create thread to check if client is alive

	hProcessMessagesThread = CreateThread(
			NULL,              // default security
			0,                 // default stack size
			ProcessMessages,        // name of the thread function
			this,              // no thread parameters
			0,                 // default startup flags
			&dwThreadID);

	if (hProcessMessagesThread == NULL)
	{
		cout<<"CreateThread for process messages failed "<< GetLastError()<<endl;
		return 1;
	}
}
//Method main which is entry point to start the TCPServer. TCPServer starts connection to the socket, 
//receive and process messages in the queue and then disconnects on timeout/client closed and is ready to accept
//connection again with a client. There is only one client accepted at a time.
int __cdecl main(void)
{
	TCPServer serverObj;
	WSADATA wsaData;

	// Initialize Winsock
	INT iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0) {
		cout << "WSAStartup failed with error:" << iResult << endl;
		return 1;
	}

	while(true) //Continuous loop to accept connections
	{
		try
		{
			iResult = serverObj.Connect(DEFAULT_PORT);
			if (iResult != 0 )
			{
				break;
			}
			serverObj.ReceiveMessages();
			serverObj.Disconnect();
		}
		catch (exception e)
		{
			cout << "Exception" << e.what() << endl;
			break;
		}
	}
	WSACleanup();

	return 0;
}
//Processing messages in a separate thread
DWORD WINAPI ProcessMessages(LPVOID lpParam)
{
	TCPServer* objTCPServer = (TCPServer*)lpParam;

	HANDLE hEvents[] = { objTCPServer->GetDisconnectEvent(), objTCPServer->queue.GetEvent() };
	DWORD dwRet = 0;
	INT iSendResult;
	while (true)
	{
		dwRet = WaitForMultipleObjects(sizeof(hEvents) / sizeof(hEvents[0]), hEvents, FALSE, INFINITE);
		Request* req = NULL;

		switch (dwRet)
		{
		case WAIT_OBJECT_0: //Event disconnect
		{
			//Flush the queue when disconnect event 
			do
			{
				req = objTCPServer->queue.Pop();
			} while (req != NULL);
			ResetEvent(objTCPServer->GetDisconnectEvent());
			SetEvent(objTCPServer->GetProcessMessagesComplete());
		}
		break;

		case WAIT_OBJECT_0 + 1: //Queue event
		{
			//got request data
			req = objTCPServer->queue.Pop();
			if (req != NULL)
			{
				Response resp;
				resp.iDeviceID = req->iDeviceID;
				resp.iResponseID = req->iRequestID;
				switch (req->binRequest)
				{
				case REQ_INITIALIZE:
					objTCPServer->ObjDevices[req->iDeviceID].SetDeviceInitialized(true);
					resp.error = RESError_Success;
					break;
				case REQ_STATUS:
					resp.error = RESError_Success;
					break;

				case REQ_ENABLE:
					objTCPServer->ObjDevices[req->iDeviceID].SetDeviceEnabled(true);
					resp.error = RESError_Success;
					break;

				case REQ_DISABLE:
					objTCPServer->ObjDevices[req->iDeviceID].SetDeviceEnabled(false);
					resp.error = RESError_Success;
					break;
				default:
					break;

				}
				resp.responseStatus = objTCPServer->ObjDevices[req->iDeviceID].GetDeviceStatus();

				iSendResult = send(objTCPServer->GetClientSocket(), (char*)&resp, sizeof(resp), 0);
				//Disconnect is not initiated in send errors. Disconnect is expected to be handled in main thread or timer call back.
				if (iSendResult == SOCKET_ERROR)
				{
					cout << "Send failed with error: " << WSAGetLastError() << endl;
				}
			}
		}
		break;

		default:
			break;
		}
	}
	return 0;
}