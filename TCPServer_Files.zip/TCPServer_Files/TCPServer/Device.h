#include "stdafx.h"
#ifndef DEFINITIONS_H
#include "Definitions.h"
#define DEFINITIONS_H

#endif

class Device
{
private:
	UINT64 iDeviceID;
	bool IsInitialized;
	bool IsEnabled;
	UINT32 iStatus;
public:
	UINT64 GetDeviceID()
	{
		return iDeviceID;
	}
	void SetDeviceID(UINT64 Id)
	{
		iDeviceID = Id;
	}
	bool GetDeviceEnabled()
	{
		return IsEnabled;
	}
	void SetDeviceEnabled(bool isEnable)
	{
		IsEnabled = isEnable;
	}

	bool GetDeviceInitialized()
	{
		return IsInitialized;
	}
	void SetDeviceInitialized(bool isInitialize)
	{
		IsInitialized = isInitialize;
	}
	UINT32 GetDeviceStatus()
	{
		if (GetDeviceInitialized() == true && GetDeviceEnabled() == true)
		{ 
			iStatus = STATUS_InitEnable;
		}
		else if (GetDeviceInitialized() == true && GetDeviceEnabled() == false)
		{
			iStatus = STATUS_InitDisable;
		}
		else if (GetDeviceInitialized() == false)
		{
			iStatus = STATUS_UnInitialized;
		}
		return iStatus;
	}

	void SetDeviceStatus(UINT32 status)
	{
		iStatus = status;
	}
};